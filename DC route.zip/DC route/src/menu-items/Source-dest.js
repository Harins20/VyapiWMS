// This is example of menu item without group for horizontal layout. There will be no children.

// third-party
import { FormattedMessage } from 'react-intl';

const SourceDestination = {
    id: 'source-dest',
    title: <FormattedMessage id="Get Routes" />,
    // icon: icons.IconBrandChrome,
    type: 'group',
    url: '/source-dest'
}

export default SourceDestination;
