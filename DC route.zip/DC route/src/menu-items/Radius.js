import { FormattedMessage } from 'react-intl';

const Radius = {
    id: 'radius',
    title: <FormattedMessage id="Get DC" />,
    // icon: icons.IconBrandChrome,
    type: 'group',
    url: '/radius'
}

export default Radius;