// This is example of menu item without group for horizontal layout. There will be no children.

// third-party
import { FormattedMessage } from 'react-intl';

const Distance = {
    id: 'distance',
    title: <FormattedMessage id="Get Distance" />,
    // icon: icons.IconBrandChrome,
    type: 'group',
    url: '/distance'
}

export default Distance;
