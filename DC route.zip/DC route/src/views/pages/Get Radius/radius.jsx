import React, { useState } from 'react';
import MainCard from 'ui-component/cards/MainCard';
import { TextField, Grid, MenuItem, Alert, Button, Snackbar, Box, CircularProgress, Radio, RadioGroup, FormControlLabel, FormControl, FormLabel } from '@mui/material';
import { MaterialReactTable } from 'material-react-table';
import { GoogleMap, LoadScript, Marker, InfoWindow, Circle } from '@react-google-maps/api';

const DCLocator = () => {
    const locations = [
        "Silchar,Assam", "Agartala,Tripura", "Dimapur,Nagaland", "Lakhimpur,Assam", "Tinsukia,Assam", "Kokrajhar,Assam", "Rani,Assam"
    ];

    const menuProps = {
        PaperProps: {
            style: {
                maxHeight: 200,
                fontSize: 12
            }
        }
    };

    const [selectedLocation, setSelectedLocation] = useState('');
    const [radius, setRadius] = useState('');
    const [tripType, setTripType] = useState('single');
    const [dc, setDCs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [activeMarker, setActiveMarker] = useState(null);
    const [circleRadius, setCircleRadius] = useState(null);

    const handleSnackbarClose = () => {
        setSnackbarOpen(false);
    };

    const fetchDCs = () => {
        if (!selectedLocation || !radius) {
            setErrorMessage('Please select a location and specify the radius');
            setSnackbarOpen(true);
            setDCs([]);
            return;
        }

        const adjustedRadius = tripType === 'round' ? radius / 2 : radius;
        setCircleRadius(adjustedRadius * 1000); // Convert km to meters

        // Hardcoded data to replace API call
        const hardcodedData = [
            { place: 'Guwahati, Assam', distance: 120, latitude: '26.1445', longitude: '91.7362' },
            { place: 'Shillong, Meghalaya', distance: 200, latitude: '25.5788', longitude: '91.8933' },
            { place: 'Imphal, Manipur', distance: 300, latitude: '24.8170', longitude: '93.9368' }
        ];

        const filteredData = hardcodedData.filter(dc => dc.place !== selectedLocation);
        setDCs(filteredData);

        setLoading(false);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            fetchDCs();
        }
    };

    const columns = [
        { header: 'DC Name', accessorKey: 'place' },
        { header: 'Distance (in km)', accessorKey: 'distance' },
        { header: 'Latitude', accessorKey: 'latitude' },
        { header: 'Longitude', accessorKey: 'longitude' },
    ];

    const containerStyle = {
        width: '100%',
        height: '400px'
    };

    const center = {
        lat: dc.length > 0 ? parseFloat(dc[0].latitude) : 26.2006,
        lng: dc.length > 0 ? parseFloat(dc[0].longitude) : 92.9376
    };

    const handleMarkerClick = (index) => {
        setActiveMarker(index);
    };

    const handleInfoWindowClose = () => {
        setActiveMarker(null);
    };

    return (
        <MainCard title="DC Locator">
            <Grid container spacing={2}>
                <Grid item xs={4}>
                    <TextField
                        label="Location"
                        select
                        fullWidth
                        value={selectedLocation}
                        onChange={(e) => setSelectedLocation(e.target.value)}
                        onKeyDown={handleKeyDown}
                        SelectProps={{ MenuProps: menuProps }}
                    >
                        {locations.map((location) => (
                            <MenuItem key={location} value={location} style={{ fontSize: 12 }}>
                                {location}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item xs={4}>
                    <TextField
                        label="Radius (in km)"
                        fullWidth
                        value={radius}
                        onChange={(e) => setRadius(e.target.value)}
                        onKeyDown={handleKeyDown}
                    />
                </Grid>
                <Grid item xs={4} style={{ textAlign: 'center' }}>
                    <FormControl component="fieldset">
                        <FormLabel component="legend">Trip Type</FormLabel>
                        <RadioGroup
                            row
                            value={tripType}
                            onChange={(e) => setTripType(e.target.value)}
                        >
                            <FormControlLabel value="single" control={<Radio />} label="Single Trip" />
                            <FormControlLabel value="round" control={<Radio />} label="Round Trip" />
                        </RadioGroup>
                    </FormControl>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                    <Button variant="contained" color="primary" onClick={fetchDCs} disabled={loading}>
                        {loading ? <CircularProgress size={24} /> : 'Fetch DC'}
                    </Button>
                </Grid>
            </Grid>
            <Grid item xs={12}>
                <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
                    <Alert onClose={handleSnackbarClose} severity="error" sx={{ width: '100%', fontWeight: 'bold' }}>
                        {errorMessage}
                    </Alert>
                </Snackbar>
            </Grid>

            {!loading && dc.length > 0 && (
                <Box mt={2}>
                    <MaterialReactTable
                        columns={columns}
                        data={dc}
                    />
                </Box>
            )}
            {!loading && dc.length > 0 && (
                <Box mt={2}>
                    <LoadScript googleMapsApiKey="AIzaSyD5j2eeZYvN7QGY7W1dkA1bIl9I6N_4dts">
                        <GoogleMap
                            mapContainerStyle={containerStyle}
                            center={center}
                            zoom={8}
                        >
                            {circleRadius && (
                                <Circle
                                    center={center}
                                    radius={circleRadius} // Use the circleRadius state
                                    options={{
                                        strokeColor: '#0000FF',
                                        strokeOpacity: 0.8,
                                        strokeWeight: 2,
                                        fillColor: '#ADD8E6',
                                        fillOpacity: 0.35,
                                    }}
                                />
                            )}
                            {dc.map((dc, index) => (
                                <Marker
                                    key={index}
                                    position={{ lat: parseFloat(dc.latitude), lng: parseFloat(dc.longitude) }}
                                    label={dc.place}
                                    onClick={() => handleMarkerClick(index)}
                                >
                                    {activeMarker === index && (
                                        <InfoWindow onCloseClick={handleInfoWindowClose}>
                                            <div>
                                                <strong>{dc.place}</strong><br />
                                                Distance: {dc.distance} km
                                            </div>
                                        </InfoWindow>
                                    )}
                                </Marker>
                            ))}
                        </GoogleMap>
                    </LoadScript>
                </Box>
            )}
        </MainCard>
    );
};

export default DCLocator;
