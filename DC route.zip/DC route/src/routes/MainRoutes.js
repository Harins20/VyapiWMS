import { lazy } from 'react';

// project imports
// import AuthGuard from 'utils/route-guard/AuthGuard';
import MainLayout from 'layout/MainLayout';
import Loadable from 'ui-component/Loadable';

// sample page routing
const SourceDest = Loadable(lazy(() => import('views/pages/Get Routes/source-dest')));
const Distance = Loadable(lazy(() => import('views/pages/Get Distance/distance')));
const Radius = Loadable(lazy(() => import('views/pages/Get Radius/radius')));

// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
    path: '/',
    element: (
        // <AuthGuard>
            <MainLayout />
        // </AuthGuard>
    ),
    children: [
        // {
        //     path: '/',
        //     element: <SamplePage />
        // },
        {
            path: '/source-dest',
            element: <SourceDest />
        },
        {
            path: '/distance',
            element: <Distance />
        },
        {
            path: '/radius',
            element: <Radius />
        },
    ]
};

export default MainRoutes;
