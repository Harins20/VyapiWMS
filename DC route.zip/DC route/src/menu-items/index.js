// import other from './other';
// import pages from './pages';
import SourceDestination from './Source-dest';
import Distance from './Distance';
import Radius from './Radius';


// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
    items: [SourceDestination, Distance, Radius]
};

export default menuItems;
