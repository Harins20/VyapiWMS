import React, { useState } from 'react';
import MainCard from 'ui-component/cards/MainCard';
import { TextField, Grid, MenuItem, Alert, Button, Snackbar, Box, CircularProgress, Typography, Card, CardContent, Divider } from '@mui/material';

const DistanceCalculator = () => {
    const locations = [
        // List of all locations
        "Barpeta,Assam", "Bongaigaon,Assam", "Silchar,Assam", "Mongaldoi,Assam", "Dibrugarh,Assam",
        "Jorhat,Assam", "Dispur,Assam", "Lakhimpur,Assam", "Nagaon,Assam", "Tezpur,Assam",
        "Tinsukia,Assam", "Biswanath Charali,Assam", "Dhemaji,Assam", "Dhubri,Assam", "Golaghat,Assam",
        "Hailakandi,Assam", "Hojai,Assam", "Kokrajhar,Assam", "Udalguri,Assam", "Karimganj,Assam",
        "Goalpara,Assam", "Sivasagar,Assam", "Hatsingimari,Assam", "Pathsala,Assam", "Haflong,Assam",
        "Mushalpur,Assam", "Sonari,Assam", "Kajalgaon,Assam", "Amingaon,Assam", "Diphu,Assam",
        "Hamren,Assam", "Garamur,Assam", "Morigaon,Assam", "Nalbari,Assam",
        "Pasighat,Arunachal Pradesh", "Ziro,Arunachal Pradesh", "Tezu,Arunachal Pradesh", "Yupia,Arunachal Pradesh", "Namsai,Arunachal Pradesh", "Khonsa,Arunachal Pradesh", "Bomdilla,Arunachal Pradesh",
        "Aalo,Arunachal Pradesh", "Roiing,Arunachal Pradesh", "Boleng,Arunachal Pradesh", "Likabali,Arunachal Pradesh", "Basar,Arunachal Pradesh", "Longding,Arunachal Pradesh",
        "Seppa,Arunachal Pradesh", "Daporijo,Arunachal Pradesh", "Tawang Town,Arunachal Pradesh", "Changlang,Arunachal Pradesh", "Yingkiong,Arunachal Pradesh", "Anini,Arunachal Pradesh",
        "Koloriang,Arunachal Pradesh", "Hawai,Arunachal Pradesh", "Jamin,Arunachal Pradesh", "Raga,Arunachal Pradesh", "Tato,Arunachal Pradesh", "Lemmi,Arunachal Pradesh",
        "Shillong,Meghalaya", "Nongpoh,Meghalaya", "Jowai,Meghalaya", "Nongstain,Meghalaya", "Mawkyrwat,Meghalaya", "Tura,Meghalaya", "Ampati,Meghalaya", "Khliehriat,Meghalaya", "Resubelpara,Meghalaya", "Williamnagar,Meghalaya", "Baghmara,Meghalaya",
        "Porompat,Manipur", "Lamphelpat,Manipur", "Bishnupur,Manipur", "Thoubal,Manipur", "Senapati,Manipur", "Ukhrul,Manipur", "Chandel,Manipur", "Churachandpur,Manipur", "Tamenglong,Manipur",
        "Jiribam,Manipur", "Kangpokpi,Manipur", "Kakching,Manipur", "Tengnoupal,Manipur", "Kamjong,Manipur", "Noney,Manipur", "Pherzawl,Manipur",
        "Aizwal,Mizoram", "Lunglei,Mizoram", "Champhai,Mizoram", "Kolasib,Mizoram", "Mamit,Mizoram", "Lawngtlai,Mizoram", "Saiha,Mizoram", "Serchhip,Mizoram", "Hnahthial,Mizoram", "Khawzawl,Mizoram", "Saitual,Mizoram",
        "Dimapur,Nagaland", "Kohima,Nagaland", "Longleng,Nagaland", "Mokokchong,Nagaland", "Tuensang,Nagaland", "Wokha,Nagaland", "Mon,Nagaland", "Peren,Nagaland", "Phek,Nagaland", "Zunheboto,Nagaland", "Noklak,Nagaland",
        "Gangtok,Sikkim", "Namchi,Sikkim", "Geyzing,Sikkim", "Mangan,Sikkim", "Agartala,Tripura", "Dharmanagar,Tripura", "Ambasa,Tripura", "Udaipur,Tripura", "Kailashahar,Tripura", "Belonia,Tripura", "Bishramganj,Tripura", "Khowai,Tripura"
    ];

    const hardcodedDistances = {
        "Barpeta,Assam-Bongaigaon,Assam": 50,
        "Silchar,Assam-Dibrugarh,Assam": 350,
        // Add more hardcoded distances here
    };

    const menuProps = {
        PaperProps: {
            style: {
                maxHeight: 200,
                fontSize: 12
            }
        }
    };

    // State management
    const [source, setSource] = useState('');
    const [destination, setDestination] = useState('');
    const [displayedSource, setDisplayedSource] = useState('');
    const [displayedDestination, setDisplayedDestination] = useState('');
    const [totalDistance, setTotalDistance] = useState(null); // To store the total distance
    const [loading, setLoading] = useState(false); // New loading state
    const [errorMessage, setErrorMessage] = useState('');
    const [snackbarOpen, setSnackbarOpen] = useState(false);

    // Handle closing of Snackbar
    const handleSnackbarClose = () => {
        setSnackbarOpen(false);
    };

    const fetchDistance = () => {
        // Check if source and destination are the same
        if (source === destination) {
            setErrorMessage('Source and Destination are the same!');
            setSnackbarOpen(true);
            setTotalDistance(null);
        } else {
            const key = `${source}-${destination}`;
            const reverseKey = `${destination}-${source}`;
            const distance = hardcodedDistances[key] || hardcodedDistances[reverseKey];

            if (distance !== undefined) {
                setTotalDistance(distance);
                setDisplayedSource(source);
                setDisplayedDestination(destination);
                setErrorMessage('');
            } else {
                setErrorMessage('Distance not found!');
                setSnackbarOpen(true);
                setTotalDistance(null);
            }

            setLoading(false); // Set loading to false when fetch is done
        }
    };

    // Handle pressing Enter key to fetch distance
    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            fetchDistance();
        }
    };

    return (
        <MainCard title="Get Distance">
            <Grid container spacing={2}>
                <Grid item xs={6}>
                    <TextField
                        label="Source"
                        select
                        fullWidth
                        value={source}
                        onChange={(e) => setSource(e.target.value)}
                        onKeyDown={handleKeyDown}
                        SelectProps={{ MenuProps: menuProps }}
                    >
                        {/* Render source locations */}
                        {locations.map((location) => (
                            <MenuItem key={location} value={location} style={{ fontSize: 12 }}>
                                {location}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item xs={6}>
                    <TextField
                        label="Destination"
                        select
                        fullWidth
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        onKeyDown={handleKeyDown}
                        SelectProps={{ MenuProps: menuProps }}
                    >
                        {/* Render destination locations */}
                        {locations.map((location) => (
                            <MenuItem key={location} value={location} style={{ fontSize: 12 }}>
                                {location}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                    <Button variant="contained" color="primary" onClick={fetchDistance} disabled={loading}>
                        {loading ? 'Loading...' : 'Get Distance'}
                    </Button>
                </Grid>
            </Grid>
            <Grid item xs={12}>
                <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
                    <Alert onClose={handleSnackbarClose} severity="error" sx={{ width: '100%', fontWeight: 'bold' }}>
                        {errorMessage}
                    </Alert>
                </Snackbar>
            </Grid>
            {loading && (
                <Box mt={2} display="flex" justifyContent="center">
                    {/* Show loading spinner when data is being fetched */}
                    <CircularProgress />
                </Box>
            )}
            {!loading && totalDistance !== null && (
                <Box mt={2} display="flex" justifyContent="center">
                    {/* Show distance when data is loaded */}
                    <Card style={{ maxWidth: 400, margin: 'auto', textAlign: 'center' }}>
                        <CardContent>
                            <Typography variant="h3" component="div" gutterBottom>
                                Distance Information
                            </Typography>
                            <Divider />
                            <Box mt={2}>
                                <Typography variant="h4" component="div">
                                    <strong>Source: </strong>
                                    <Typography variant="h4" component="span" style={{ fontWeight: 'normal' }}>
                                        {displayedSource}
                                    </Typography>
                                </Typography>
                                <Typography variant="h4" component="div" mt={1}>
                                    <strong>Destination: </strong>
                                    <Typography variant="h4" component="span" style={{ fontWeight: 'normal' }}>
                                        {displayedDestination}
                                    </Typography>
                                </Typography>
                                <Typography variant="h4" component="div" mt={3}>
                                    <strong>Total Distance: </strong>
                                    <Typography variant="h4" component="span" style={{ fontWeight: 'normal' }}>
                                        {totalDistance} km
                                    </Typography>
                                </Typography>
                            </Box>
                        </CardContent>
                    </Card>
                </Box>
            )}
        </MainCard>
    );
}

export default DistanceCalculator;
