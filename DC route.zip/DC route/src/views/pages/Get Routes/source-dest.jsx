import React, { useState } from 'react';
import MainCard from 'ui-component/cards/MainCard';
import { TextField, Grid, MenuItem, Alert, Button, Snackbar, Box, CircularProgress } from '@mui/material';
import axios from 'axios';
import { MaterialReactTable } from 'material-react-table';
import { GoogleMap, LoadScript, Marker, Polyline, InfoWindow } from '@react-google-maps/api';

const SourceDest = () => {
    const locations = [
        "Barpeta,Assam", "Bongaigaon,Assam", "Silchar,Assam", "Mongaldoi,Assam", "Dibrugarh,Assam",
        "Jorhat,Assam", "Dispur,Assam", "Lakhimpur,Assam", "Nagaon,Assam", "Tezpur,Assam",
        "Tinsukia,Assam", "Biswanath Charali,Assam", "Dhemaji,Assam", "Dhubri,Assam", "Golaghat,Assam",
        "Hailakandi,Assam", "Hojai,Assam", "Kokrajhar,Assam", "Udalguri,Assam", "Karimganj,Assam",
        "Goalpara,Assam", "Sivasagar,Assam", "Hatsingimari,Assam", "Pathsala,Assam", "Haflong,Assam",
        "Mushalpur,Assam", "Sonari,Assam", "Kajalgaon,Assam", "Amingaon,Assam", "Diphu,Assam",
        "Hamren,Assam", "Garamur,Assam", "Morigaon,Assam", "Nalbari,Assam",
        "Pasighat,Arunachal Pradesh", "Ziro,Arunachal Pradesh", "Tezu,Arunachal Pradesh", "Yupia,Arunachal Pradesh", "Namsai,Arunachal Pradesh", "Khonsa,Arunachal Pradesh", "Bomdilla,Arunachal Pradesh",
        "Aalo,Arunachal Pradesh", "Roiing,Arunachal Pradesh", "Boleng,Arunachal Pradesh", "Likabali,Arunachal Pradesh", "Basar,Arunachal Pradesh", "Longding,Arunachal Pradesh",
        "Seppa,Arunachal Pradesh", "Daporijo,Arunachal Pradesh", "Tawang Town,Arunachal Pradesh", "Changlang,Arunachal Pradesh", "Yingkiong,Arunachal Pradesh", "Anini,Arunachal Pradesh",
        "Koloriang,Arunachal Pradesh", "Hawai,Arunachal Pradesh", "Jamin,Arunachal Pradesh", "Raga,Arunachal Pradesh", "Tato,Arunachal Pradesh", "Lemmi,Arunachal Pradesh",
        "Shillong,Meghalaya", "Nongpoh,Meghalaya", "Jowai,Meghalaya", "Nongstain,Meghalaya", "Mawkyrwat,Meghalaya", "Tura,Meghalaya", "Ampati,Meghalaya", "Khliehriat,Meghalaya", "Resubelpara,Meghalaya", "Williamnagar,Meghalaya", "Baghmara,Meghalaya",
        "Porompat,Manipur", "Lamphelpat,Manipur", "Bishnupur,Manipur", "Thoubal,Manipur", "Senapati,Manipur", "Ukhrul,Manipur", "Chandel,Manipur", "Churachandpur,Manipur", "Tamenglong,Manipur",
        "Jiribam,Manipur", "Kangpokpi,Manipur", "Kakching,Manipur", "Tengnoupal,Manipur", "Kamjong,Manipur", "Noney,Manipur", "Pherzawl,Manipur",
        "Aizwal,Mizoram", "Lunglei,Mizoram", "Champhai,Mizoram", "Kolasib,Mizoram", "Mamit,Mizoram", "Lawngtlai,Mizoram", "Saiha,Mizoram", "Serchhip,Mizoram", "Hnahthial,Mizoram", "Khawzawl,Mizoram", "Saitual,Mizoram",
        "Dimapur,Nagaland", "Kohima,Nagaland", "Longleng,Nagaland", "Mokokchong,Nagaland", "Tuensang,Nagaland", "Wokha,Nagaland", "Mon,Nagaland", "Peren,Nagaland", "Phek,Nagaland", "Zunheboto,Nagaland", "Noklak,Nagaland",
        "Gangtok,Sikkim", "Namchi,Sikkim", "Geyzing,Sikkim", "Mangan,Sikkim", "Agartala,Tripura", "Dharmanagar,Tripura", "Ambasa,Tripura", "Udaipur,Tripura", "Kailashahar,Tripura", "Belonia,Tripura", "Bishramganj,Tripura", "Khowai,Tripura"
    ];

    const menuProps = {
        PaperProps: {
            style: {
                maxHeight: 200,
                fontSize: 12
            }
        }
    };

    const [source, setSource] = useState('');
    const [destination, setDestination] = useState('');
    const [places, setPlaces] = useState([]);
    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [activeMarker, setActiveMarker] = useState(null);

    const handleSnackbarClose = () => {
        setSnackbarOpen(false);
    };

    const fetchPlaces = () => {
        if (!source || !destination) {
            setErrorMessage('Please select the Source and Destination');
            setSnackbarOpen(true);
            setPlaces([]);
            return;
        }

        if (source === destination) {
            setErrorMessage('Source and Destination are the same!');
            setSnackbarOpen(true);
            setPlaces([]);
            return;
        }

        setErrorMessage('');
        setLoading(true);

        axios.get(`http://92.205.17.11:1020/Routes/GetInbetweenPlaces`, {
            params: {
                Source: source,
                Destination: destination
            }
        })
            .then(response => {
                setPlaces(response.data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                setErrorMessage('Error fetching data');
                setSnackbarOpen(true);
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            fetchPlaces();
        }
    };

    const columns = [
        { header: 'Place', accessorKey: 'place' },
        { header: 'Distance (in km)', accessorKey: 'distance' },
        { header: 'Latitude', accessorKey: 'latitude' },
        { header: 'Longitude', accessorKey: 'longitude' },
    ].map(column => ({
        ...column,
        Cell: ({ cell, row }) => (
            <div style={{ fontWeight: row.original.place === destination ? 'bold' : 'normal' }}>
                {cell.getValue()}
            </div>
        ),
        Header: () => (
            <div style={{ fontWeight: 'bold' }}>
                {column.header}
            </div>
        )
    }));

    const containerStyle = {
        width: '100%',
        height: '400px'
    };

    const center = {
        lat: places.length > 0 ? parseFloat(places[0].latitude) : 26.2006,
        lng: places.length > 0 ? parseFloat(places[0].longitude) : 92.9376
    };

    const pathCoordinates = places.map(place => ({
        lat: parseFloat(place.latitude),
        lng: parseFloat(place.longitude)
    }));

    const handleMarkerClick = (index) => {
        setActiveMarker(index);
    };

    const handleInfoWindowClose = () => {
        setActiveMarker(null);
    };

    return (
        <MainCard title="Source-Dest">
            <Grid container spacing={2}>
                <Grid item xs={6}>
                    <TextField
                        label="Source"
                        select
                        fullWidth
                        value={source}
                        onChange={(e) => setSource(e.target.value)}
                        onKeyDown={handleKeyDown}
                        SelectProps={{ MenuProps: menuProps }}
                    >
                        {locations.map((location) => (
                            <MenuItem key={location} value={location} style={{ fontSize: 12 }}>
                                {location}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item xs={6}>
                    <TextField
                        label="Destination"
                        select
                        fullWidth
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        onKeyDown={handleKeyDown}
                        SelectProps={{ MenuProps: menuProps }}
                    >
                        {locations.map((location) => (
                            <MenuItem key={location} value={location} style={{ fontSize: 12 }}>
                                {location}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'center' }}>
                    <Button variant="contained" color="primary" onClick={fetchPlaces} disabled={loading}>
                        {loading ? <CircularProgress size={24} /> : 'Fetch Places'}
                    </Button>
                </Grid>
            </Grid>
            <Grid item xs={12}>
                <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
                    <Alert onClose={handleSnackbarClose} severity="error" sx={{ width: '100%', fontWeight: 'bold' }}>
                        {errorMessage}
                    </Alert>
                </Snackbar>
            </Grid>

            {!loading && places.length > 0 && (
                <Box mt={2}>
                    <MaterialReactTable
                        columns={columns}
                        data={places.filter((_, index) => index !== 0)} // Filter out the source for the table
                        getRowProps={row => ({
                            style: {
                                fontWeight: row.original.place === destination ? 'bold' : 'normal'
                            }
                        })}
                    />
                </Box>
            )}
            {!loading && places.length > 0 && (
                <Box mt={2}>
                    <LoadScript googleMapsApiKey="AIzaSyD5j2eeZYvN7QGY7W1dkA1bIl9I6N_4dts">
                        <GoogleMap
                            mapContainerStyle={containerStyle}
                            center={center}
                            zoom={8}
                        >
                            <Marker
                                position={{ lat: parseFloat(places[0].latitude), lng: parseFloat(places[0].longitude) }}
                                label={places[0].place}
                            />
                            {places.slice(1).map((place, index) => (
                                <Marker
                                    key={index + 1}
                                    position={{ lat: parseFloat(place.latitude), lng: parseFloat(place.longitude) }}
                                    label={place.place}
                                    onClick={() => handleMarkerClick(index + 1)}
                                >
                                    {activeMarker === index + 1 && (
                                        <InfoWindow onCloseClick={handleInfoWindowClose}>
                                            <div>
                                                <strong>{place.place}</strong><br />
                                                Distance: {place.distance} km
                                            </div>
                                        </InfoWindow>
                                    )}
                                </Marker>
                            ))}
                            <Polyline
                                path={pathCoordinates}
                                options={{ strokeColor: '#FF0000' }}
                            />
                        </GoogleMap>
                    </LoadScript>
                </Box>
            )}
        </MainCard>
    );
};

export default SourceDest;
